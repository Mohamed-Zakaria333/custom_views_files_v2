

import UIKit
@IBDesignable
class My_LBL: UILabel {
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable var borderColor: UIColor = .black {
        didSet {
            layer.borderColor = borderColor.cgColor
        }
    }
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            layer.cornerRadius = cornerRadius
            layer.masksToBounds = cornerRadius > 0
        }
    }
    //***********************************
    @IBInspectable var leftInset: CGFloat = 0.0 {
        didSet {
            
        }
    }
    
    @IBInspectable var rightInset: CGFloat = 0.0 {
        didSet {
            
        }
    }
    
    @IBInspectable var topInset: CGFloat = 0.0 {
        didSet {
            
        }
    }
    
    @IBInspectable var bottomInset: CGFloat = 0.0 {
        didSet {
            
        }
        
    }
    
    override func drawText(in rect: CGRect) {
        let insets = UIEdgeInsets.init(top: topInset, left: leftInset, bottom: bottomInset, right: rightInset)
        super.drawText(in: UIEdgeInsetsInsetRect(rect, insets))
    }
    
    override var intrinsicContentSize: CGSize {
        let size = super.intrinsicContentSize
        return CGSize(width: size.width + leftInset + rightInset,
                      height: size.height + topInset + bottomInset)
    }
    //*************************************
}
